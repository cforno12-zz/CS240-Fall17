- type 'make' to create executable 'run'
- 'run' will greet you with a command prompt
- to INSERT a string type: i <string>
- to FIND the index of a string type: f <int>
- to CAPITALIZE the first letter of a string type: c <int>
- to CAP ALL of a string type: a <int>
- to TRUNCATE: t <index_int> <length>
- to GET SHORTEST: s
- to GET FIRST: gf
- to PRINT all three vectors: p
- to QUIT: q

PRINTING:
the first vector is the length vector (lH) with the indices.
the second vector is alphabetical (alpha) same format of the length vector
the last vector contains the string along with the location of where it resides in the other vectors

TEST CASES:
test01.txt - tests the find function, CAPITALIZE function, and cap all function
test02.txt - tests TRUNCATE, GET SHORTEST, and GET first.
